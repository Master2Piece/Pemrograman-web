<?= $this->extend('layout/template');?>
<?= $this->section('content');?>

<div class="container">
    <div class="row">
        <div class="cols">
        <div class="container">
  <div class="jumbotron">
    <h1>Device Management System</h1>
    <p>See device's information in one go!</p> 
  </div>
  <div class="row">
    <div class="col-sm-4">
      <h3>What can you do?</h3>
      <p>You can see how many devices in this system</p>
      <p>You can also see what status of the devices</p>
    </div>
    <div class="col-sm-4">
      <h3>How many device in this web?</h3>
      <p>Recently there are 3 devices in this web</p>

    </div>
    <div class="col-sm-4">
      <h3>F&Q</h3>        
      <p>You can ask about device management system in this email MloT.business@gmail.com</p>
    </div>
  </div>
</div>
        </div>
    </div>
</div>

<?= $this->endSection();?>
